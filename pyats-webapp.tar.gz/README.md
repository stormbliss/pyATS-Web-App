# PyATS Web Application

A modern web interface for PyATS network automation, built with FastAPI and React.

## Features

- **Testbed Management**
  - Upload and validate PyATS testbed YAML files
  - Generate testbed templates for various device types
  - Store multiple testbeds with versioning

- **Device Connectivity**
  - Test connectivity to all devices in a testbed
  - Execute commands on individual devices
  - View real-time command output

- **Multi-Vendor Support**
  - Cisco IOS, IOS-XE, IOS-XR, NX-OS
  - Juniper JunOS
  - Arista EOS
  - Cisco ASA

## Prerequisites

- Ubuntu 20.04 / 22.04 / 24.04
- Python 3.8+
- Node.js 18+
- Nginx

## Installation

### Quick Start (Recommended)

```bash
# Make deployment script executable
chmod +x deploy.sh

# Run deployment (requires sudo)
sudo ./deploy.sh
```

The script will:
1. Install all system dependencies
2. Set up Python virtual environment
3. Install pyATS and required packages
4. Build React frontend
5. Configure Nginx reverse proxy
6. Create systemd service
7. Initialize database with default admin user

### Manual Installation

If you prefer manual installation, follow these steps:

1. **Install System Dependencies**
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv nodejs npm nginx sqlite3
```

2. **Setup Backend**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -m app.core.init_db
```

3. **Setup Frontend**
```bash
cd frontend
npm install
npm run build
```

4. **Configure Nginx**
```bash
sudo cp config/nginx.conf /etc/nginx/sites-available/pyats-webapp
sudo ln -s /etc/nginx/sites-available/pyats-webapp /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

5. **Start Backend**
```bash
cd backend
source venv/bin/activate
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

## Post-Installation

### Access the Application

After deployment, access the application at:
- **Local:** http://localhost
- **Network:** http://YOUR_SERVER_IP

### Default Credentials

- **Username:** admin
- **Password:** admin123

**⚠️ Change the default password immediately after first login!**

### Service Management

```bash
# Check status
systemctl status pyats-webapp

# Restart service
systemctl restart pyats-webapp

# View logs
journalctl -u pyats-webapp -f

# Stop service
systemctl stop pyats-webapp
```

## Usage Guide

### 1. Generate Testbed Template

1. Navigate to **Testbeds** → **Generate Template**
2. Fill in device details:
   - Device name
   - Hostname/IP address
   - Device type (Cisco IOS, JunOS, etc.)
   - Username
   - Protocol (SSH/Telnet)
3. Click **Generate Template**
4. Download or copy the generated YAML

### 2. Upload Testbed

1. Navigate to **Testbeds** → **Upload Testbed**
2. Select your testbed YAML file
3. System validates the file automatically
4. View validation results

### 3. Test Device Connectivity

1. Go to **Testbeds** and select a testbed
2. Click **Devices** button
3. Click **Test Connectivity**
4. View connection status for all devices

### 4. Execute Commands

1. In Device Manager, select a device
2. Enter a command (e.g., `show version`)
3. Click **Execute Command**
4. View output in real-time

## Testbed File Format

Example testbed YAML structure:

```yaml
testbed:
  name: my_network
  credentials:
    default:
      username: admin
      password: %ASK{}  # Prompts for password

devices:
  router1:
    type: router
    os: ios
    platform: cisco_ios
    connections:
      cli:
        protocol: ssh
        ip: 192.168.1.1
        port: 22

  switch1:
    type: switch
    os: nxos
    platform: cisco_nxos
    connections:
      cli:
        protocol: ssh
        ip: 192.168.1.2
        port: 22
```

## Supported Device Types

| Vendor | OS | Platform Value |
|--------|----|--------------  |
| Cisco | IOS | `cisco_ios` |
| Cisco | IOS-XE | `cisco_iosxe` |
| Cisco | IOS-XR | `cisco_iosxr` |
| Cisco | NX-OS | `cisco_nxos` |
| Cisco | ASA | `cisco_asa` |
| Juniper | JunOS | `juniper_junos` |
| Arista | EOS | `arista_eos` |

## Configuration

### Environment Variables

Create `.env` file in backend directory:

```bash
# Application
DEBUG=False

# Database
DATABASE_URL=sqlite:///./data/pyats.db

# Security
SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=1440

# Paths
TESTBED_DIR=./data/testbeds
JOBS_DIR=./data/jobs
```

### File Locations

- **Application:** `/opt/pyats-webapp/`
- **Database:** `/opt/pyats-webapp/data/pyats.db`
- **Testbeds:** `/opt/pyats-webapp/data/testbeds/`
- **Logs:** `journalctl -u pyats-webapp`

## Troubleshooting

### Backend not starting

```bash
# Check logs
journalctl -u pyats-webapp -n 50

# Verify virtual environment
source /opt/pyats-webapp/backend/venv/bin/activate
which python3
```

### Frontend not loading

```bash
# Check Nginx status
systemctl status nginx

# Test Nginx configuration
nginx -t

# View Nginx error logs
tail -f /var/log/nginx/error.log
```

### Database issues

```bash
# Reinitialize database
cd /opt/pyats-webapp/backend
source venv/bin/activate
python3 -m app.core.init_db
```

### Permission errors

```bash
# Fix ownership
sudo chown -R pyats:pyats /opt/pyats-webapp

# Fix permissions
sudo chmod -R 755 /opt/pyats-webapp
```

## Security Considerations

1. **Change default password** immediately
2. **Use HTTPS** in production (configure SSL/TLS)
3. **Restrict network access** to trusted IPs
4. **Regularly update** system packages
5. **Secure SSH keys** for device access
6. **Use strong passwords** for device credentials

## Development

### Backend Development

```bash
cd backend
source venv/bin/activate
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend Development

```bash
cd frontend
npm start
```

## API Documentation

Interactive API documentation available at:
- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

## Support

For issues or questions:
1. Check logs: `journalctl -u pyats-webapp -f`
2. Review this README
3. Check PyATS documentation: https://developer.cisco.com/docs/pyats/

## License

This project is for internal use. Ensure compliance with Cisco pyATS licensing.

## Version

**Version:** 1.0.0  
**Last Updated:** December 2024
